#include "consoleui.h"

using namespace std;

int main()
{
    ConsoleUI ui;
    ui.run();

    return 0;
}
